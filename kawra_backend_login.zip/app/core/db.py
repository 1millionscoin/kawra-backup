from .config import settings
if settings.DB_BACKEND == "postgres":
    from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
    from sqlalchemy.orm import declarative_base
    Base = declarative_base()
    engine = create_async_engine(settings.POSTGRES_DSN, future=True, echo=False)
    SessionLocal = async_sessionmaker(engine, expire_on_commit=False)
else:
    # Mongo mode
    from motor.motor_asyncio import AsyncIOMotorClient
    client = AsyncIOMotorClient(settings.MONGO_DSN)
    db = client["kawra"]
    Base = None  # not used
    engine = None
    SessionLocal = None
